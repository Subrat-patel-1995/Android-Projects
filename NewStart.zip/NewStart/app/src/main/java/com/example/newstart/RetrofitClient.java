package com.example.newstart;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static Retrofit retrofit;
    private static String URL="https://reqres.in/";

    public static Retrofit getRetrofitInstnce(){
        if(retrofit==null){
            retrofit=new Retrofit.Builder().baseUrl(URL)
                    .addConverterFactory(GsonConverterFactory.create()).build();

        }
        return retrofit;
    }


     //    TODO 2
}
